package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText editText;

    private TextView InputText,resultTextView;

    private String currentInput = "";
    private boolean calculationPerformed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        InputText = findViewById(R.id.InputText);
        resultTextView = findViewById(R.id.resultTextView);

        initializeButtons();
    }

    private void initializeButtons() {
        int[] buttonIds = {
                R.id.button13, R.id.button14, R.id.button15, R.id.button16,
                R.id.button9, R.id.button10, R.id.button11, R.id.button12,
                R.id.button5, R.id.button6, R.id.button7, R.id.button8,
                R.id.button1, R.id.button2, R.id.button3, R.id.button4
        };

        String[] buttonValues = {
                "7", "8", "9", "/",
                "4", "5", "6", "*",
                "1", "2", "3", "-",
                ".", "0", "=", "+"
        };

        for (int i = 0; i < buttonIds.length; i++) {
            Button button = findViewById(buttonIds[i]);
            final String value = buttonValues[i];
            button.setOnClickListener(view -> onButtonClick(value));
        }

        Button buttonDelete = findViewById(R.id.button17);
        buttonDelete.setOnClickListener(v -> deleteLastCharacter());
    }


    private void onButtonClick(String value) {

        if (value.equals("=")) {
            performCalculation();
        } else if (value.equals(".")) {
            handleDecimalPoint();
        } else {
            handleNumberOrOperatorInput(value);
        }
    }

    private void handleNumberOrOperatorInput(String value) {
        if (calculationPerformed) {

            InputText.setText("");

            calculationPerformed = false;
        }
        currentInput += value;
        InputText.setText(currentInput);
    }

    private void handleDecimalPoint() {
        if (!currentInput.contains(".")) {
            currentInput += ".";
            InputText.setText(currentInput);
        }
    }

    private void performCalculation() {
        try {
            double result = evaluateExpression(currentInput);

            resultTextView.setText(String.valueOf(result));
            calculationPerformed = true;
        } catch (Exception e) {
            resultTextView.setText("Error");
        }
    }


    public static double evaluateExpression(String expression) throws IllegalArgumentException {

        Expression exp = new ExpressionBuilder(expression).build();

        return exp.evaluate();
    }

    private void deleteLastCharacter() {
        if (currentInput.length() > 0) {
            currentInput = currentInput.substring(0, currentInput.length() - 1);
            InputText.setText(currentInput);

        }

        if(currentInput.length()==0){
            resultTextView.setText("");
        }
    }
}